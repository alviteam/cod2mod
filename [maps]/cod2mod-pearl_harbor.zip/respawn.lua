function respawnRustlers()
	for i,vehicle in ipairs(getElementsByType("vehicle")) do
		toggleVehicleRespawn(vehicle, true)
		setVehicleRespawnDelay(vehicle, 1000)
	end
end
addEventHandler("onResourceStart", getResourceRootElement(getThisResource()), respawnRustlers)